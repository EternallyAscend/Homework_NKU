% ~means ignore the value;
% such as the [~,p]= [1,2] means the p = 2; 

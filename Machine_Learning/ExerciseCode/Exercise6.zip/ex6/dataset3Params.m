function [C, sigma] = dataset3Params(X, y, Xval, yval)
%EX6PARAMS returns your choice of C and sigma for Part 3 of the exercise
%where you select the optimal (C, sigma) learning parameters to use for SVM
%with RBF kernel
%   [C, sigma] = EX6PARAMS(X, y, Xval, yval) returns your choice of C and 
%   sigma. You should complete this function to return the optimal C and 
%   sigma based on a cross-validation set.
%

% You need to return the following variables correctly.
C = 1;
sigma = 0.1;

% ====================== YOUR CODE HERE ======================
% Instructions: Fill in this function to return the optimal C and sigma
%               learning parameters found using the cross validation set.
%               You can use svmPredict to predict the labels on the cross
%               validation set. For example, 
%                   predictions = svmPredict(model, Xval);
%               will return the predictions on the cross validation set.
%
%  Note: You can compute the prediction error using 
%        mean(double(predictions ~= yval))
%
model= svmTrain(X, y, C, @(x1, x2) gaussianKernel(x1, x2, sigma));
predictions=svmPredict(model,Xval);
temp_C=[0.01 0.03 0.1 0.3 1 3 10 30];
temp_sigma=temp_C;
temp_mean=mean(double(predictions ~=yval));
[r,c]=size(temp_C);
for i=1:c
    for j=1:c
        model=svmTrain(X,y,temp_C(1,i),@(x1,x2) gaussianKernel(x1,x2,temp_sigma(1,j)));
        predictions=svmPredict(model,Xval);
        temp=mean(double(predictions ~=yval));
        if temp<temp_mean
            temp_mean=temp;
            C=temp_C(1,i);
            sigma=temp_sigma(1,j);
        end
    end
end

% disp(C);
% disp(sigma);

% =========================================================================

end

# NKCS-2019-Summer-Qt-Project.
# Saved in 2019.07.15 12:15
A simple program desinged by Qt5.13 (MSVC2017) in 2019.

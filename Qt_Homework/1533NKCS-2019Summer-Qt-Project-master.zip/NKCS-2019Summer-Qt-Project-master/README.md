# NKCS-2019Summer-Qt-Project
A simple program designed by Qt5.13.0 (MSVC2017) in 2019.
